// data.js
const profiles = [
    {
      id: 1,
      userID: '1',
      favoriteMovieID: '1',
    },
    // more records...
  ];
  
  const users = {
    1: {
      id: 1,
      name: 'Jane Cruz',
      userName: 'coder',
    },
    // more records...
  };
  
  const movies = {
    1: {
      id: 1,
      name: 'Planet Earth 1',
    },
    // more records...
  };
  
  export {profiles, users, movies};